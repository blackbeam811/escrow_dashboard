import CreateStep1 from "./createStep1";
const CreateOffer = () => {
  return (
    <CreateStep1 />
    
  );
};

export default CreateOffer;
