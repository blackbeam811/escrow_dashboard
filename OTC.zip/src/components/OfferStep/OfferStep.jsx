import { GetStart } from "./Components/GetStart/GetStart";
import { OfferDetails } from "./Components/OfferDetails/OfferDetails";
import { Offer } from "./Components/Offer/Offer";

import React, { useState, useEffect, useRef } from "react";
import {
  useAccount,
  usePublicClient,
  useWalletClient,
  useBalance,
  useNetwork,
  useSwitchNetwork,
} from "wagmi";
import { toast } from "react-toastify";
// import logoImage from "../images/logoLoad.png";
import logoImage from "../../images/logoLoad.png";
import EscrowServices from "../services/EscrowServices.js";
import config from "../config.js";
import LinearProgress from "@mui/material/LinearProgress";

export const OfferStep = () => {
  const [active, setActive] = useState(0);

  const { connector: activeConnector, isConnected, address } = useAccount();
  const { data: walletClient, isError, isLoading } = useWalletClient();
  const publicClient = usePublicClient();
  const [tokenAddress, setTokenAddress] = useState("");
  const [isAddressValid, setIsAddressValid] = useState(true);
  const [tokenBalance, setTokenBalance] = useState(0);
  const [tokenSymbol, setTokenSymbol] = useState("-");
  const [tokenName, setTokenName] = useState("-");
  const [tokenPriceInEth, setTokenPriceInEth] = useState(0);
  const [tokenPriceInEthTimestamp, setTokenPriceInEthTimestamp] = useState(0);
  const [ethAmountInput, setEthAmountInput] = useState("");
  const [tokenAmountInput, setTokenAmountInput] = useState("");
  const [chunkSizeInput, setChunkSizeInput] = useState("1");
  const [showPopup, setShowPopup] = useState(false);
  const [ethBalance, setUserEthBalance] = useState();
  const { chain: currentChain } = useNetwork();
  const [offertoken, setOffertoken] = useState("-");
  const [fortoken, setFortoken] = useState("-");
  const [offeringAddress, setOfferingAddress] = useState("");
  const [forAddress, setForAddress] = useState("");

  const loadStates = async () => {
    EscrowServices.setClient(publicClient);
    const ethBalance = await EscrowServices.fetchEthBalance(address);
    setUserEthBalance(ethBalance);

    console.log("Loading states...");
  };

  useEffect(() => {
    if (isConnected && currentChain?.id === config.arbitrumChainId) {
      loadStates();
      const img = new Image();
      img.src = logoImage;

      return () => {};
    }
  }, [address, isConnected, currentChain]);

  // Call fetchTokenBalance whenever tokenAddress or address changes
  useEffect(() => {
    fetchTokenDetails();
  }, [tokenAddress, address]);

  const fetchTokenDetails = async () => {
    if (tokenAddress !== "" && address !== "" && isAddressValid === true) {
      const [balance, tokenSymbol, tokenName, priceInEth, timestamp] =
        await EscrowServices.fetchTokenDetails(address, tokenAddress);
      setTokenBalance(balance);
      setTokenSymbol(tokenSymbol);
      setTokenName(tokenName);
      setTokenPriceInEth(priceInEth);
      setTokenPriceInEthTimestamp(timestamp);
    }
  };

  // const handleCreateSingleCoinOffer = async () => {
  //   try {
  //     //setShowLoading(true)
  //     console.log("ethKSDFJSDF", ethAmountInput);
  //     const txHash = await EscrowServices.createSingleCoinOffer(
  //       address,
  //       walletClient,
  //       ethAmountInput,
  //       tokenAmountInput,
  //       chunkSizeInput,
  //       tokenAddress,
  //       ethAmountInput,
  //       "0x30fA2FbE15c1EaDfbEF28C188b7B8dbd3c1Ff2eB"
  //     );
  //     const txUrl = `${config.arbiscanUrl}${txHash}`;
  //     toast.success(
  //       <div>
  //         Created ETH for Token Offer! <br /> <br />{" "}
  //         <a href={txUrl} target="_blank" rel="noopener noreferrer">
  //           View transaction
  //         </a>
  //       </div>
  //     );
  //     //setShowLoading(false)
  //     await loadStates();
  //   } catch (error) {
  //     toast.error(`${error.message}`);
  //     //setShowLoading(false)
  //   }
  // };
  const handleCreateSingleCoinOffer = async () => {
    try {
      //setShowLoading(true)
      const txHash = await EscrowServices.createSingleCoinOffer(
        address,
        walletClient,
        ethAmountInput,
        tokenAmountInput,
        chunkSizeInput,
        tokenAddress
      );
      const txUrl = `${config.arbiscanUrl}${txHash}`;
      toast.success(
        <div>
          Created ETH for Token Offer! <br /> <br />{" "}
          <a href={txUrl} target="_blank" rel="noopener noreferrer">
            View transaction
          </a>
        </div>
      );
      //setShowLoading(false)
      await loadStates();
    } catch (error) {
      toast.error(`${error.message}`);
      //setShowLoading(false)
    }
  };
  const isValidToken = () => {
    if (tokenName === "-" || tokenName === null || tokenName === undefined) {
      return false;
    } else {
      return true;
    }
  };

  const isValidEthereumAddress = (address) => {
    return /^0x[a-fA-F0-9]{40}$/.test(address);
  };

  const checkAddress = (t, address) => {
    alert(address);
    if (t) setOfferingAddress(address);
    else setForAddress(address);
    setIsAddressValid(isValidEthereumAddress(address));
  };

  let readableTime = "-";

  if (tokenPriceInEthTimestamp !== 0) {
    const currentTime = Math.floor(Date.now() / 1000); // Get current Unix timestamp
    const timeDifference = currentTime - tokenPriceInEthTimestamp; // Calculate difference in seconds

    const hours = Math.floor(timeDifference / 3600); // Convert seconds to hours
    const minutes = Math.floor((timeDifference % 3600) / 60); // Convert remaining seconds to minutes
    const seconds = timeDifference % 60; // Get remaining seconds

    if (hours > 0) {
      readableTime = `${hours} hours, ${minutes} minutes and ${seconds} seconds ago`;
    } else if (minutes > 0) {
      readableTime = `${minutes} minutes and ${seconds} seconds ago`;
    } else if (seconds > 0) {
      readableTime = `${seconds} seconds ago`;
    } else {
      readableTime = "-";
    }
  }

  const offerPrice = ethAmountInput / tokenAmountInput;
  const priceDifference =
    ((offerPrice - tokenPriceInEth) / tokenPriceInEth) * 100;

  const STEP = [
    {
      title: "Get Started",
      content: <GetStart setActive={setActive} />,
    },
    {
      title: "Offer Details ",
      content: (
        <OfferDetails
          setActive={setActive}
          submitAddress={checkAddress}
          setTokenAmountInput={setTokenAmountInput}
          setEthAmountInput={setEthAmountInput}
          isAddressValid={isAddressValid}
          offertoken={offertoken}
          fortoken={fortoken}
          setOffertoken={setOffertoken}
          setFortoken={setFortoken}
        />
      ),
    },
    {
      title:
        "You want to Offer " +
        tokenAmountInput +
        " " +
        tokenSymbol +
        " for " +
        ethAmountInput +
        "ETH",
      content: (
        <Offer
          setActive={setActive}
          tokenSymbol={tokenSymbol}
          tokenAmountInput={tokenAmountInput}
          ethAmountInput={ethAmountInput}
          offerPrice={offerPrice}
          handleCreateSingleCoinOffer={handleCreateSingleCoinOffer}
        />
      ),
    },
  ];
  return (
    <div className="bg-[#363A41] pb-[31px] rounded-[8px] px-[52px] py-[12px] w-[710px] ">
      <div className="flex justify-between">
        <h1 className="text-white text-[25px] not-italic font-semibold leading-[normal]">
          {STEP[active].title}
        </h1>
        {/* <div className="py-[9px] bg-[#101116] rounded-[6px] px-[22px]">
          <p className="text-white text-xs not-italic font-normal leading-[normal]">
            Step {STEP.length}/{active + 1} Done
          </p>
        </div> */}
      </div>
      <div className="w-full flex justify-center my-5">
        <div className="relative border-2 border-gray-300 h-[6px] px-[45%]">
          <div
            className={
              "absolute top-[-500%] left-[-2%] w-6 h-6 rounded-[999px] bg-[#15161B] border-2 border-gray-300 flex justify-center items-center text-gray-300 text-md font-bold bg-gre" +
              (active >= 0 && " bg-green-500 border-none")
            }
          >
            1
          </div>

          <div
            className={
              "absolute top-[-500%] left-[48%] w-6 h-6 rounded-[999px] bg-[#15161B] border-2 border-gray-300 flex justify-center items-center text-gray-300 text-md font-bold bg-gre" +
              (active >= 1 && " bg-green-500 border-none")
            }
          >
            2
          </div>
          <div
            className={
              "absolute top-[-500%] left-[100%] w-6 h-6 rounded-[999px] bg-[#15161B] border-2 border-gray-300 flex justify-center items-center text-gray-300 text-md font-bold bg-gre" +
              (active >= 2 && " bg-green-500 border-none")
            }
          >
            3
          </div>
        </div>
      </div>
      {STEP[active].content}
    </div>
  );
};
