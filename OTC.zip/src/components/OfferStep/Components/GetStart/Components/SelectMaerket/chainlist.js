export const chains = [
  {
    icon: "icon-[logos--ethereum]",
    title: "Ethereum",
  },
  {
    icon: "",
    title: "Optimism",
  },
  {
    icon: "",
    title: "BNB Chain",
  },
  {
    icon: "",
    title: "zkSync",
  },
  {
    icon: "",
    title: "Scroll",
  },
  {
    icon: "token--linea",
    title: "Linea",
  },
  {
    icon: "",
    title: "Blast",
  },
  {
    icon: "",
    title: "Manta",
  },
  {
    icon: "",
    title: "Pacific",
  },
  {
    icon: "",
    title: "Starknet",
  },
  {
    icon: "",
    title: "Merlin",
  },
  {
    icon: "",
    title: "Base",
  },
  {
    icon: "",
    title: "Arbitrum",
  },
];
