import { createContext } from "react";

export const WalletContext = createContext(0);
